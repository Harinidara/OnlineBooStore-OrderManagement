package com.capgemini.service;

import com.capgemini.entity.Order;

public interface OrderService {

	String updateCustomerInfo(Order order);

}
